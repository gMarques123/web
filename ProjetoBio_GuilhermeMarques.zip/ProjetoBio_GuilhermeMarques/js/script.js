// Aguarda o DOM carregar completamente
document.addEventListener('DOMContentLoaded', function() {


    // VARIÁVEIS GLOBAIS

    const formulario       = document.getElementById('formulario-contato');
    const btnLimpar        = document.getElementById('btn-limpar');
    const mensagemSucesso  = document.getElementById('mensagem-sucesso');
    const btnLerMais       = document.getElementById('btn-ler-mais');
    const textoExtra       = document.getElementById('texto-extra');
    const btnMenu          = document.getElementById('btn-menu');
    const menuNav          = document.getElementById('menu-nav');
    const spanAno          = document.getElementById('ano-atual');

    // Campos do formulário
    const campoNome      = document.getElementById('nome');
    const campoEmail     = document.getElementById('email');
    const campoMensagem  = document.getElementById('mensagem');

    // Mensagens de erro
    const erroNome      = document.getElementById('erro-nome');
    const erroEmail     = document.getElementById('erro-email');
    const erroMensagem  = document.getElementById('erro-mensagem');

    // Controle do texto expandido
    let textoExpandido = false;

    // Controle do tema
    let modoEscuro = false;



    // 1. NAVEGAÇÃO ENTRE PÁGINAS

    window.mostrarPagina = function(paginaId) {
        // Esconde todas as seções
        const todasSecoes = document.querySelectorAll('.secao');
        todasSecoes.forEach(function(secao) {
            secao.classList.remove('ativa');
        });

        // Mostra a seção escolhida
        const secaoEscolhida = document.getElementById('secao-' + paginaId);
        if (secaoEscolhida) {
            secaoEscolhida.classList.add('ativa');
        }

        // Anima as barras de habilidade ao entrar em habilidades
        if (paginaId === 'habilidades') {
            animarBarras();
        }

        // Fecha o menu mobile se estiver aberto
        menuNav.classList.remove('aberto');
        btnMenu.setAttribute('aria-expanded', 'false');

        // Volta para o topo da página
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // 2. MENU MOBILE (HAMBURGER)

    window.alternarMenu = function() {
        const estaAberto = menuNav.classList.contains('aberto');

        if (estaAberto) {
            menuNav.classList.remove('aberto');
            btnMenu.setAttribute('aria-expanded', 'false');
        } else {
            menuNav.classList.add('aberto');
            btnMenu.setAttribute('aria-expanded', 'true');
        }
    };

    // 3. ALTERNAR TEMA CLARO / ESCURO

    window.alternarTema = function() {
        const btnTema = document.getElementById('btn-tema');

        modoEscuro = !modoEscuro;

        if (modoEscuro) {
            document.body.classList.add('modo-escuro');
            btnTema.textContent = '☀️ Modo Claro';
        } else {
            document.body.classList.remove('modo-escuro');
            btnTema.textContent = '🌙 Modo Escuro';
        }
    };

    // 4. BOTÃO "LER MAIS" — SOBRE

    window.mostrarMais = function() {
        textoExpandido = !textoExpandido;

        if (textoExpandido) {
            textoExtra.classList.add('visivel');
            btnLerMais.textContent = 'Mostrar menos ↑';
        } else {
            textoExtra.classList.remove('visivel');
            btnLerMais.textContent = 'Ler mais ↓';
        }
    };

    // 5. ANIMAÇÃO DAS BARRAS DE HABILIDADE

    let barrasAnimadas = false;

    function animarBarras() {
        if (barrasAnimadas) return;
        barrasAnimadas = true;

        const barras = document.querySelectorAll('.barra-progresso');

        barras.forEach(function(barra, indice) {
            const nivel = barra.getAttribute('data-nivel');

            setTimeout(function() {
                barra.style.width = nivel + '%';
            }, indice * 100);
        });
    }

    // 6. VALIDAÇÃO DO FORMULÁRIO

    // Valida o campo nome
    function validarNome() {
        const nome = campoNome.value.trim();

        if (nome === '') {
            erroNome.textContent = '❌ O nome é obrigatório';
            campoNome.classList.add('campo-erro');
            return false;
        }

        if (nome.length < 3) {
            erroNome.textContent = '❌ O nome deve ter pelo menos 3 caracteres';
            campoNome.classList.add('campo-erro');
            return false;
        }

        erroNome.textContent = '';
        campoNome.classList.remove('campo-erro');
        return true;
    }

    // Valida o campo e-mail
    function validarEmail() {
        const email = campoEmail.value.trim();
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email === '') {
            erroEmail.textContent = '❌ O e-mail é obrigatório';
            campoEmail.classList.add('campo-erro');
            return false;
        }

        if (!regexEmail.test(email)) {
            erroEmail.textContent = '❌ Digite um e-mail válido';
            campoEmail.classList.add('campo-erro');
            return false;
        }

        erroEmail.textContent = '';
        campoEmail.classList.remove('campo-erro');
        return true;
    }

    // Valida o campo mensagem
    function validarMensagem() {
        const mensagem = campoMensagem.value.trim();

        if (mensagem === '') {
            erroMensagem.textContent = '❌ A mensagem é obrigatória';
            campoMensagem.classList.add('campo-erro');
            return false;
        }

        if (mensagem.length < 10) {
            erroMensagem.textContent = '❌ A mensagem deve ter pelo menos 10 caracteres';
            campoMensagem.classList.add('campo-erro');
            return false;
        }

        erroMensagem.textContent = '';
        campoMensagem.classList.remove('campo-erro');
        return true;
    }

    // Limpa o formulário
    function limparFormulario() {
        formulario.reset();

        erroNome.textContent     = '';
        erroEmail.textContent    = '';
        erroMensagem.textContent = '';

        campoNome.classList.remove('campo-erro');
        campoEmail.classList.remove('campo-erro');
        campoMensagem.classList.remove('campo-erro');

        mensagemSucesso.style.display = 'none';
    }

    // Envia o formulário
    function enviarFormulario(evento) {
        evento.preventDefault();

        const nomeValido      = validarNome();
        const emailValido     = validarEmail();
        const mensagemValida  = validarMensagem();

        if (!nomeValido || !emailValido || !mensagemValida) {
            return;
        }

        // Mostra mensagem de sucesso
        mensagemSucesso.style.display = 'block';

        // Limpa o formulário depois de 3 segundos
        setTimeout(function() {
            limparFormulario();
        }, 3000);
    }

    // 7. ANO AUTOMÁTICO NO RODAPÉ

    const anoAtual = new Date().getFullYear();
    spanAno.textContent = anoAtual;

    // EVENTOS

    // Envio do formulário
    formulario.addEventListener('submit', enviarFormulario);

    // Botão limpar
    btnLimpar.addEventListener('click', limparFormulario);

    // Validação em tempo real ao perder o foco
    campoNome.addEventListener('blur', validarNome);
    campoEmail.addEventListener('blur', validarEmail);
    campoMensagem.addEventListener('blur', validarMensagem);

    // Remove erro ao digitar
    campoNome.addEventListener('input', function() {
        if (campoNome.value.trim() !== '') {
            erroNome.textContent = '';
            campoNome.classList.remove('campo-erro');
        }
    });

    campoEmail.addEventListener('input', function() {
        if (campoEmail.value.trim() !== '') {
            erroEmail.textContent = '';
            campoEmail.classList.remove('campo-erro');
        }
    });

    campoMensagem.addEventListener('input', function() {
        if (campoMensagem.value.trim() !== '') {
            erroMensagem.textContent = '';
            campoMensagem.classList.remove('campo-erro');
        }
    });

});
